class User {
  static SCHEDULE = 'SCHEDULE';
  static CLIENT = 'CLIENT'
  static DAC = 'DAC';
}

export default User;
