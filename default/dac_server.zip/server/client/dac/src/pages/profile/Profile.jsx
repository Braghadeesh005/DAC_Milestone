import React from 'react'
import MainLayout from '../../layouts/MainLayout'

const Profile = () => {
  return (
    <MainLayout>
      Profile
    </MainLayout>
  )
}

export default Profile
