import React from 'react'
import MainLayout from '../../layouts/MainLayout'

const FirewallHome = () => {
  return (
    <MainLayout>
      <div>Firewall HOME</div>
    </MainLayout>
  )
}

export default FirewallHome
