class Level {
  static FINE = 'FINE';
  static ERROR = 'ERROR';
  static INFO = 'INFO';
  static WARNING = 'WARNING';
  static DEBUG = 'DEBUG';
}

export default Level;
