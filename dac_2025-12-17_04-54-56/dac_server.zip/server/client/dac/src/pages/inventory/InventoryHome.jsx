import React from 'react'
import MainLayout from '../../layouts/MainLayout'

const InventoryHome = () => {
  return (
    <MainLayout>
      <div>Inventory HOME</div>
    </MainLayout>
  )
}

export default InventoryHome
