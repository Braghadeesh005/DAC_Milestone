import React from 'react'
import MainLayout from '../../layouts/MainLayout'

const LbHome = () => {
  return (
    <MainLayout>
      <div>LB HOME</div>
    </MainLayout>
  )
}

export default LbHome
